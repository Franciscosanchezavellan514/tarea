﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;

namespace WinFormsApp
{
    public partial class Form1 : Form
    {
        private VentaService ventaService = new VentaService();
        private int ventaId = -1;
        public Form1()
        {
            InitializeComponent();
            CargarVentas();

        }
        private void CargarVentas()
        {

   

            var ventas = ventaService.ObtenerVentas();
            dataGridView1.DataSource = ventas;

           
            if (dataGridView1.Columns.Contains("Id"))
            {
                dataGridView1.Columns["Id"].Visible = false; 
            }
        }




        private void LimpiarCampos()
        {
            txtNombreEmpleado.Clear();
            txtNombreProducto.Clear();
            txtCantidad.Clear();
            txtPrecio.Clear();
            txtTotal.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void CalcularTotal()
        {
            if (decimal.TryParse(txtCantidad.Text, out decimal cantidad) && decimal.TryParse(txtPrecio.Text, out decimal precio))
            {
                txtTotal.Text = (cantidad * precio).ToString("C");
            }
            else
            {
                txtTotal.Clear();
            }
        }
        private void txtCantidad_TextChanged(object sender, EventArgs e)
        {
            CalcularTotal();
        }

        private void txtPrecio_TextChanged(object sender, EventArgs e)
        {
            CalcularTotal();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string nombreEmpleado = txtNombreEmpleado.Text;
            string nombreProducto = txtNombreProducto.Text;
            int cantidad = int.Parse(txtCantidad.Text);
            decimal precio = decimal.Parse(txtPrecio.Text);

            if (ventaId == -1)
            {
              
                ventaService.AgregarVenta(nombreEmpleado, nombreProducto, cantidad, precio);
            }
            else
            {
               
                ventaService.ModificarVenta(ventaId, nombreEmpleado, nombreProducto, cantidad, precio);
                ventaId = -1;
            }

            LimpiarCampos();
            CargarVentas();
            MessageBox.Show("Operación realizada con éxito.");
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            ventaId = -1;
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (ventaId != -1)
            {
                ventaService.EliminarVenta(ventaId);
                LimpiarCampos();
                CargarVentas();
                MessageBox.Show("Venta eliminada con éxito.");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) 
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                ventaId = Convert.ToInt32(row.Cells["Id"].Value); 
            }
        }
    }
}
