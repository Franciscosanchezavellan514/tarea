﻿using System.Data.SqlClient;

namespace DataLayer
{
    public class DatabaseHelper
    {
        
        private string connectionString = ("Data Source=DESKTOP-UMQEV96\\SQLEXPRESS;Initial Catalog=VentasDB;user ID=sa; password=12345678");

        
        public SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}
