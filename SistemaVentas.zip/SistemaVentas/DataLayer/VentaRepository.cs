﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DataLayer
{
    public class VentaRepository
    {
        private DatabaseHelper dbHelper = new DatabaseHelper();

        // Método para agregar una nueva venta
        public void AgregarVenta(string nombreEmpleado, string nombreProducto, int cantidad, decimal precio)
        {
            using (SqlConnection conn = dbHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("AgregarVenta", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@NombreEmpleado", nombreEmpleado);
                cmd.Parameters.AddWithValue("@NombreProducto", nombreProducto);
                cmd.Parameters.AddWithValue("@Cantidad", cantidad);
                cmd.Parameters.AddWithValue("@Precio", precio);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

      
        public void ModificarVenta(int id, string nombreEmpleado, string nombreProducto, int cantidad, decimal precio)
        {
            using (SqlConnection conn = dbHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("ModificarVenta", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.Parameters.AddWithValue("@NombreEmpleado", nombreEmpleado);
                cmd.Parameters.AddWithValue("@NombreProducto", nombreProducto);
                cmd.Parameters.AddWithValue("@Cantidad", cantidad);
                cmd.Parameters.AddWithValue("@Precio", precio);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

    
        public void EliminarVenta(int id)
        {
            using (SqlConnection conn = dbHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("EliminarVenta", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@Id", id);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

   
        public DataTable ObtenerVentas()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = dbHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Ventas", conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }
    }
}
