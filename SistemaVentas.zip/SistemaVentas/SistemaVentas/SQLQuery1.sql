CREATE DATABASE VentasDB;
GO

USE VentasDB;
GO

CREATE TABLE Ventas (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    NombreEmpleado NVARCHAR(100),
    NombreProducto NVARCHAR(100),
    Cantidad INT,
    Precio DECIMAL(18,2),
    Total DECIMAL(18,2)
);
GO

-- Procedimiento para agregar una venta
CREATE PROCEDURE AgregarVenta
    @NombreEmpleado NVARCHAR(100),
    @NombreProducto NVARCHAR(100),
    @Cantidad INT,
    @Precio DECIMAL(18,2)
AS
BEGIN
    INSERT INTO Ventas (NombreEmpleado, NombreProducto, Cantidad, Precio, Total)
    VALUES (@NombreEmpleado, @NombreProducto, @Cantidad, @Precio, @Cantidad * @Precio);
END;
GO

-- Procedimiento para modificar una venta
CREATE PROCEDURE ModificarVenta
    @Id INT,
    @NombreEmpleado NVARCHAR(100),
    @NombreProducto NVARCHAR(100),
    @Cantidad INT,
    @Precio DECIMAL(18,2)
AS
BEGIN
    UPDATE Ventas
    SET NombreEmpleado = @NombreEmpleado,
        NombreProducto = @NombreProducto,
        Cantidad = @Cantidad,
        Precio = @Precio,
        Total = @Cantidad * @Precio
    WHERE Id = @Id;
END;
GO

-- Procedimiento para eliminar una venta
CREATE PROCEDURE EliminarVenta
    @Id INT
AS
BEGIN
    DELETE FROM Ventas WHERE Id = @Id;
END;
GO
