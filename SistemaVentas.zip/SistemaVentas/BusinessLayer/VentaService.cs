﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer;

namespace BusinessLayer
{
    public class VentaService
    {
        private VentaRepository repository = new VentaRepository();

        public void AgregarVenta(string nombreEmpleado, string nombreProducto, int cantidad, decimal precio)
        {
            repository.AgregarVenta(nombreEmpleado, nombreProducto, cantidad, precio);
        }

        public void ModificarVenta(int id, string nombreEmpleado, string nombreProducto, int cantidad, decimal precio)
        {
            repository.ModificarVenta(id, nombreEmpleado, nombreProducto, cantidad, precio);
        }

        public void EliminarVenta(int id)
        {
            repository.EliminarVenta(id);
        }

        public DataTable ObtenerVentas()
        {
            return repository.ObtenerVentas();
        }
    }

}

